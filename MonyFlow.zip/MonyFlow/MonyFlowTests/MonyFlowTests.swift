//
//  MonyFlowTests.swift
//  MonyFlowTests
//
//  Created by Даниил Иванов on 5/26/26.
//

import Testing
@testable import MonyFlow

struct MonyFlowTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
